package com.jazzy.androidca1

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_alarm_active.*
import kotlinx.android.synthetic.main.custom_toast.*
import kotlinx.android.synthetic.main.custom_toast2.*
import kotlinx.android.synthetic.main.custom_toast3.*
import kotlinx.android.synthetic.main.rateus.*

class AlarmActive : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm_active)
        var mp = MediaPlayer.create(applicationContext,R.raw.alarmclock)
        mp.start()
        stop.setOnClickListener {
            mp.stop()
            Toast(this).apply{
                duration = Toast.LENGTH_LONG
                setGravity(Gravity.CENTER,0,0)
                view = layoutInflater.inflate(R.layout.rateus,rateus_toast)
            }.show()
        }
        btn_rating.setOnClickListener {
            if(ratingbar.rating>3.5){
                Toast(this).apply{
                    duration = Toast.LENGTH_LONG
                    setGravity(Gravity.CENTER,0,0)
                    view = layoutInflater.inflate(R.layout.custom_toast,parentLayout)
                }.show()

            }else if(ratingbar.rating<3.5 && ratingbar.rating>1){
                Toast(this).apply{
                    duration = Toast.LENGTH_LONG
                    setGravity(Gravity.CENTER,0,0)
                    view = layoutInflater.inflate(R.layout.custom_toast2,parentLayouttwo)
                }.show()

            }
            else{
                Toast(this).apply{
                    duration = Toast.LENGTH_LONG
                    setGravity(Gravity.CENTER,0,0)
                    view = layoutInflater.inflate(R.layout.custom_toast3,parentLayoutthree)
                }.show()
            }

        }
    }
}