package com.jazzy.androidca1

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.RatingBar
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_meditate.*
import kotlinx.android.synthetic.main.custom_toast.*
import kotlinx.android.synthetic.main.custom_toast2.*
import kotlinx.android.synthetic.main.custom_toast3.*
import kotlinx.android.synthetic.main.startmed.*

class Meditate : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meditate)

        settimer.setOnClickListener {
            var min : Int = edittext.text.toString().toInt()
            var i = Intent(applicationContext,MyBroadcast::class.java)
            var pendingintent = PendingIntent.getBroadcast(applicationContext,111,i,0)
            var alarmmanager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmmanager.set(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+(min*1000*60),pendingintent)
            Toast(this).apply{
                duration = Toast.LENGTH_LONG
                setGravity(Gravity.CENTER,0,0)
                view = layoutInflater.inflate(R.layout.startmed,startmedlayout)
            }.show()
            edittext.setText("")
            edittext.clearFocus()

        }

    }
}