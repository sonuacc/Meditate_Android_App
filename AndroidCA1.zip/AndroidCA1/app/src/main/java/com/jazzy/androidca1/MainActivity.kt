package com.jazzy.androidca1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btn_letsstart = findViewById<Button>(R.id.btn_letsstart)
        btn_letsstart.setOnClickListener {
            val intent = Intent(this, Meditate::class.java)
            startActivity(intent)
        }
    }
}